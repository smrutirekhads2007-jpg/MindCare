// Motivational Quotes Rotator
const motivationalQuotes = [
  "You are not defined by your darkest moments, but by your ability to rise above them. Every scar is a testament to your strength, and every setback is a setup for a greater comeback.",
  "The fire within you is stronger than any storm outside. When you feel like giving up, remember the reason why you began, and let that reason light your way through the shadows.",
  "In the depths of despair, remember: even the longest night will end and the sun will rise. Hold on, fight on, for your story is not over yet.",
  "Sometimes the bravest thing you can do is to keep going, even when the world feels heavy. Your persistence is powerful; every step forward is a victory over yesterday.",
  "No one else can walk your path, but you are never truly alone. With every breath, you build resilience, and with every challenge, you uncover a deeper strength.",
  "It’s okay to break down; it’s okay to feel lost. But always remember, you possess an unbreakable spirit and a heart capable of unimaginable healing and hope.",
  "Don’t just survive—ignite. The world needs your spark, your story, your hope. You are the author of your next chapter, and it begins today.",
  "If your mind tells you 'I can't,' answer with 'Watch me.' There is a warrior inside you waiting for the chance to prove how fiercely you can love and live.",
  "You are the hero of your own story. Every day you choose to keep going, you turn the page toward a brighter chapter.",
  "No matter how heavy the darkness feels, even the smallest light—your hope, your courage—can begin to illuminate the way."
];
let quoteIdx = 0;
function showRotatingQuote() {
  const rotator = document.getElementById('motivationRotator');
  if(rotator) {
    rotator.textContent = motivationalQuotes[quoteIdx];
    quoteIdx = (quoteIdx + 1) % motivationalQuotes.length;
  }
}

// Universal loading overlay handler
function showLoadingOverlay() {
  const overlay = document.getElementById('loadingOverlay');
  if (overlay) {
    setTimeout(() => {
      overlay.style.opacity = "0";
      setTimeout(() => {
        overlay.style.display = "none";
      }, 700);
    }, 1800);
  }
}
document.addEventListener("DOMContentLoaded", function () {
  // Quote rotator
  showRotatingQuote();
  setInterval(showRotatingQuote, 5400);

  // Loading overlay
  showLoadingOverlay();

  // Appointment form handler
  const form = document.getElementById("appointmentForm");
  if (form) {
    form.onsubmit = function (e) {
      e.preventDefault();
      const name = form.name.value.trim();
      const email = form.email.value.trim();
      const date = form.date.value;
      const psychiatrist = form.psychiatrist.value;

      if (name && email && date && psychiatrist) {
        document.getElementById("appointmentStatus").innerHTML = `
          <span style="color:#1976d2"><b>Thank you, ${name}!</b> Your appointment request with ${psychiatrist} for ${date} has been received. We will contact you at ${email}.</span>`;
        form.reset();
      }
    };
  }
});

// chatbot.js (Rule-Based)
document.addEventListener('DOMContentLoaded', () => {
    const chatbotButton = document.getElementById('chatbot-button');
    const chatbotWindow = document.getElementById('chatbot-window');
    const chatMessages = document.getElementById('chat-messages');
    const userInput = document.getElementById('user-input');
    const sendButton = document.getElementById('send-button');

    // Pre-defined responses
    const responses = {
        'depression': 'Depression is a serious condition. Our test can help assess symptoms, but please consult a doctor for diagnosis.',
        'help': 'I can answer questions about our depression test or general mental health tips. What do you need?',
        'test': 'Take our depression test on this site. It\'s not a diagnosis—seek professional advice.',
        'default': 'I\'m here to help with your depression test website. Ask about symptoms, resources, or anything else!'
    };

    chatbotButton.addEventListener('click', () => {
        chatbotWindow.style.display = chatbotWindow.style.display === 'none' ? 'flex' : 'none';
        if (chatbotWindow.style.display === 'flex' && chatMessages.children.length === 0) {
            addMessage('bot', 'How Can I Assist You?');
        }
    });

    sendButton.addEventListener('click', sendMessage);
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage();
    });

    function sendMessage() {
        const message = userInput.value.trim().toLowerCase();
        if (!message) return;

        addMessage('user', userInput.value);
        userInput.value = '';

        // Match to responses
        let reply = responses.default;
        for (const key in responses) {
            if (message.includes(key)) {
                reply = responses[key];
                break;
            }
        }

        addMessage('bot', reply);
    }

    function addMessage(sender, text) {
        const messageDiv = document.createElement('div');
        messageDiv.className =` message ${sender};`
        messageDiv.textContent = text;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
});